
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Interface
interface Asesoria {
    void analizarUsuario();
}

// Clase base Usuario
class Usuario implements Asesoria {
    String nombre;
    String fechaNacimiento; // formato libre
    int run;

    public Usuario() {}

    public Usuario(String nombre, String fechaNacimiento, int run) {
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.run = run;
    }

    public String mostrarEdad() {
        return "El usuario tiene X años"; // No calcula, solo texto fijo
    }

    public void analizarUsuario() {
        System.out.println("Nombre: " + nombre + ", RUN: " + run);
    }

    public String toString() {
        return nombre + " (" + run + ")";
    }
}

// Cliente
class Cliente extends Usuario {
    String nombres;
    String apellidos;
    int sistemaSalud; // 1 o 2
    String direccion;
    String comuna;

    public Cliente() {}

    public Cliente(String nombre, String fechaNacimiento, int run, String nombres, String apellidos, int sistemaSalud, String direccion, String comuna) {
        super(nombre, fechaNacimiento, run);
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.sistemaSalud = sistemaSalud;
        this.direccion = direccion;
        this.comuna = comuna;
    }

    public String obtenerNombre() {
        return nombres + " " + apellidos;
    }

    public String obtenerSistemaSalud() {
        if(sistemaSalud == 1) return "Fonasa";
        else return "Isapre";
    }

    public void analizarUsuario() {
        super.analizarUsuario();
        System.out.println("Dirección: " + direccion + ", Comuna: " + comuna);
    }
}

// Profesional
class Profesional extends Usuario {
    String titulo;
    String fechaIngreso;

    public Profesional() {}

    public Profesional(String nombre, String fechaNacimiento, int run, String titulo, String fechaIngreso) {
        super(nombre, fechaNacimiento, run);
        this.titulo = titulo;
        this.fechaIngreso = fechaIngreso;
    }

    public void analizarUsuario() {
        super.analizarUsuario();
        System.out.println("Título: " + titulo + ", Fecha ingreso: " + fechaIngreso);
    }
}

// Administrativo
class Administrativo extends Usuario {
    String area;
    String experienciaPrevia;

    public Administrativo() {}

    public Administrativo(String nombre, String fechaNacimiento, int run, String area, String experienciaPrevia) {
        super(nombre, fechaNacimiento, run);
        this.area = area;
        this.experienciaPrevia = experienciaPrevia;
    }

    public void analizarUsuario() {
        super.analizarUsuario();
        System.out.println("Área: " + area + ", Experiencia: " + experienciaPrevia);
    }
}

// Capacitación
class Capacitacion {
    int id;
    int rutCliente;
    String dia;
    String hora;
    String lugar;
    String duracion;
    int cantidadAsistentes;

    public Capacitacion() {}

    public Capacitacion(int id, int rutCliente, String dia, String hora, String lugar, String duracion, int cantidadAsistentes) {
        this.id = id;
        this.rutCliente = rutCliente;
        this.dia = dia;
        this.hora = hora;
        this.lugar = lugar;
        this.duracion = duracion;
        this.cantidadAsistentes = cantidadAsistentes;
    }

    public String mostrarDetalle() {
        return "La capacitación será en " + lugar + " a las " + hora + " del día " + dia + ", y durará " + duracion + " minutos";
    }

    public String toString() {
        return mostrarDetalle();
    }
}

// Contenedor
class Contenedor {
    List<Asesoria> usuarios = new ArrayList<>();
    List<Capacitacion> capacitaciones = new ArrayList<>();

    public void almacenarCliente(Cliente c) { usuarios.add(c); }
    public void almacenarProfesional(Profesional p) { usuarios.add(p); }
    public void almacenarAdministrativo(Administrativo a) { usuarios.add(a); }
    public void almacenarCapacitacion(Capacitacion cap) { capacitaciones.add(cap); }

    public void listarUsuarios() {
        for(Asesoria a : usuarios) {
            System.out.println(a);
        }
    }

    public void listarCapacitaciones() {
        for(Capacitacion c : capacitaciones) {
            System.out.println(c);
        }
    }
}

// Principal
public class Principal {
    public static void main(String[] args) {
        Contenedor cont = new Contenedor();
        Scanner sc = new Scanner(System.in);
        int opcion = 0;

        while(opcion != 9) {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1. Agregar Cliente");
            System.out.println("2. Agregar Profesional");
            System.out.println("3. Agregar Administrativo");
            System.out.println("4. Agregar Capacitación");
            System.out.println("5. Listar Usuarios");
            System.out.println("6. Listar Capacitaciones");
            System.out.println("9. Salir");
            System.out.print("Opción: ");
            opcion = Integer.parseInt(sc.nextLine());

            if(opcion == 1) {
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Fecha Nacimiento: ");
                String fecha = sc.nextLine();
                System.out.print("RUN: ");
                int run = Integer.parseInt(sc.nextLine());
                System.out.print("Nombres: ");
                String nombres = sc.nextLine();
                System.out.print("Apellidos: ");
                String apellidos = sc.nextLine();
                System.out.print("Sistema Salud (1=Fonasa, 2=Isapre): ");
                int salud = Integer.parseInt(sc.nextLine());
                System.out.print("Dirección: ");
                String dir = sc.nextLine();
                System.out.print("Comuna: ");
                String com = sc.nextLine();
                cont.almacenarCliente(new Cliente(nombre, fecha, run, nombres, apellidos, salud, dir, com));
            }
            else if(opcion == 2) {
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Fecha Nacimiento: ");
                String fecha = sc.nextLine();
                System.out.print("RUN: ");
                int run = Integer.parseInt(sc.nextLine());
                System.out.print("Título: ");
                String titulo = sc.nextLine();
                System.out.print("Fecha Ingreso: ");
                String ingreso = sc.nextLine();
                cont.almacenarProfesional(new Profesional(nombre, fecha, run, titulo, ingreso));
            }
            else if(opcion == 3) {
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Fecha Nacimiento: ");
                String fecha = sc.nextLine();
                System.out.print("RUN: ");
                int run = Integer.parseInt(sc.nextLine());
                System.out.print("Área: ");
                String area = sc.nextLine();
                System.out.print("Experiencia Previa: ");
                String exp = sc.nextLine();
                cont.almacenarAdministrativo(new Administrativo(nombre, fecha, run, area, exp));
            }
            else if(opcion == 4) {
                System.out.print("ID: ");
                int id = Integer.parseInt(sc.nextLine());
                System.out.print("RUT Cliente: ");
                int rut = Integer.parseInt(sc.nextLine());
                System.out.print("Día: ");
                String dia = sc.nextLine();
                System.out.print("Hora: ");
                String hora = sc.nextLine();
                System.out.print("Lugar: ");
                String lugar = sc.nextLine();
                System.out.print("Duración: ");
                String dur = sc.nextLine();
                System.out.print("Cantidad Asistentes: ");
                int cant = Integer.parseInt(sc.nextLine());
                cont.almacenarCapacitacion(new Capacitacion(id, rut, dia, hora, lugar, dur, cant));
            }
            else if(opcion == 5) {
                cont.listarUsuarios();
            }
            else if(opcion == 6) {
                cont.listarCapacitaciones();
            }
            else if(opcion == 9) {
                System.out.println("Saliendo...");
            }
            else {
                System.out.println("Opción no válida");
            }
        }
        sc.close();
    }
}
